from django.contrib.auth.models import User

class Admin(User):
    pass