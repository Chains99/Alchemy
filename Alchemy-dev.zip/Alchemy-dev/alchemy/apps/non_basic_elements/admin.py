from django.contrib import admin

from apps.non_basic_elements.models import NonBasicElement

admin.site.register(NonBasicElement)
