from django.apps import AppConfig


class NonBasicElementsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.non_basic_elements'
