from django.contrib import admin

from apps.elements.models import Element

admin.site.register(Element)
