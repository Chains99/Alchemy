from django.contrib import admin

from apps.study.models import Study

admin.site.register(Study)
