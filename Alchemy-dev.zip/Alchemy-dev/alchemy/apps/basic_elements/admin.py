from django.contrib import admin

from apps.basic_elements.models import BasicElement

admin.site.register(BasicElement)
