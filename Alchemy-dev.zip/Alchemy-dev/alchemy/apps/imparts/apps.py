from django.apps import AppConfig


class ImpartsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.imparts'
