from django.contrib import admin
from .models import Imparts

admin.site.register(Imparts)